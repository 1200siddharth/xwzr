#!/usr/bin/env python
#####################################
# Installation module for dnscat2
#####################################

# AUTHOR OF MODULE NAME
AUTHOR="Jens Muecke (ryd)"

# DESCRIPTION OF THE MODULE
DESCRIPTION="This module will install/update dnscat2"

# INSTALL TYPE GIT, SVN, FILE DOWNLOAD
# OPTIONS = GIT, SVN, FILE
INSTALL_TYPE="GIT"

# LOCATION OF THE FILE OR GIT/SVN REPOSITORY
REPOSITORY_LOCATION="https://github.com/iagox86/dnscat2.git"

# WHERE DO YOU WANT TO INSTALL IT
INSTALL_LOCATION="dnscat2"

# DEPENDS FOR DEBIAN INSTALLS
DEBIAN="git ruby ruby-dev git-core build-essential make bundler"

# DEPENDS FOR FEDORA INSTALLS
FEDORA="git,make,gcc,gcc-c++,ruby-irb,rubygems,rubygem-bundler,ruby-devel,git"

# COMMANDS TO RUN AFTER
AFTER_COMMANDS="cd {INSTALL_LOCATION}client,sudo make,cd {INSTALL_LOCATION}server/, bundle install, ln -s {INSTALL_LOCATION}client/dnscat {INSTALL_LOCATION}dnscat"

# THIS WILL CREATE AN AUTOMATIC LAUNCHER FOR THE TOOL
LAUNCHER="dnscat"
